module.exports = {
	NODE_ENV: '"production"',
  ENV_CONFIG: '"dep"',
  BASE_API: '"http://218.194.168.187:8080/admin"'
}
