module.exports = {
	NODE_ENV: '"production"',
	ENV_CONFIG: '"prod"',
    BASE_API: '"https://www.example.com/admin"'
}
